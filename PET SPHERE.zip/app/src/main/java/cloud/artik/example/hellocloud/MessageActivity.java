/*
 * Copyright (C) 2017 Samsung Electronics Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package cloud.artik.example.hellocloud;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.annotation.Inherited;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import cloud.artik.api.MessagesApi;
import cloud.artik.api.UsersApi;
import cloud.artik.client.ApiCallback;
import cloud.artik.client.ApiClient;
import cloud.artik.client.ApiException;
import cloud.artik.model.Message;
import cloud.artik.model.MessageIDEnvelope;
import cloud.artik.model.NormalizedMessagesEnvelope;
import cloud.artik.model.User;
import cloud.artik.model.UserEnvelope;

import static cloud.artik.example.hellocloud.Config.DEVICE_ID;

/**
 * Modified by kje 2018-06
 * Check the message from artik cloud every 5 seconds(Can be reduced)
 * if UserTV = true, start the selected video
 */

public class MessageActivity extends Activity {
    public static Context mContext;
    private static final String TAG = "MessageActivity";

    private static UsersApi mUsersApi = null;
    private static MessagesApi mMessagesApi = null;

    private static String mAccessToken;

    public static boolean UserAircon;
    public static boolean UserHeater;
    public static boolean UserLED;
    public static int UserMotor;
    public static boolean UserTV;
    public static boolean UserCall;
    public static boolean adminOn;
    public static String VideoURL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);
        mContext = this;
        startTVAsyncTask checkTVthread = new startTVAsyncTask();

        AuthStateDAL authStateDAL = new AuthStateDAL(this);
        mAccessToken = authStateDAL.readAuthState().getAccessToken();
        Log.v(TAG, "::onCreate get access token = " + mAccessToken);


        setupArtikCloudApi();
        getUserInfo();

        getLatestMsg();
        checkTVthread.execute((Boolean) true);

    }

////////////////////////////////////////////////////////////////////////////////////////////////////
    public void setupArtikCloudApi() {
        ApiClient mApiClient = new ApiClient();
        mApiClient.setAccessToken(mAccessToken);

        mUsersApi = new UsersApi(mApiClient);
        mMessagesApi = new MessagesApi(mApiClient);
    }

    public void getUserInfo()
    {
        final String tag = TAG + " getSelfAsync";
        try {
            mUsersApi.getSelfAsync(new ApiCallback<UserEnvelope>() {
                @Override
                public void onFailure(ApiException exc, int statusCode, Map<String, List<String>> map) {
                    processFailure(tag, exc);
                }

                @Override
                public void onSuccess(UserEnvelope result, int statusCode, Map<String, List<String>> map) {
                    Log.v(TAG, "getSelfAsync::setupArtikCloudApi self name = " + result.getData().toString());
                    updateWelcomeViewOnUIThread("Welcome " + result.getData().getFullName());
                }

                @Override
                public void onUploadProgress(long bytes, long contentLen, boolean done) {
                }

                @Override
                public void onDownloadProgress(long bytes, long contentLen, boolean done) {
                }
            });
        } catch (ApiException exc) {
            processFailure(tag, exc);
        }
    }

    public void getLatestMsg() {
        final String tag = TAG + " getLastNormalizedMessagesAsync";
        try {
            int messageCount = 1;
            mMessagesApi.getLastNormalizedMessagesAsync(messageCount, DEVICE_ID, null,
                    new ApiCallback<NormalizedMessagesEnvelope>() {
                        @Override
                        public void onFailure(ApiException exc, int i, Map<String, List<String>> stringListMap) {
                            processFailure(tag, exc);
                        }

                        @Override
                        public void onSuccess(NormalizedMessagesEnvelope result, int i, Map<String, List<String>> stringListMap) {
                            Log.v(tag, " onSuccess latestMessage = " + result.getData().toString());

                            String mid = "";
                            String data = "";
                            if (!result.getData().isEmpty()) {
                                mid = result.getData().get(0).getMid();
                                data = result.getData().get(0).getData().toString();
                            }


                            if (data.contains("adminOn=true")) {
                                adminOn = true;
                            } else {
                                adminOn = false;
                            }
                            if (data.contains("UserLED=true")) {
                                UserLED = true;
                            } else {
                                UserLED = false;
                            }
                            if (data.contains("UserHeater=true")) {
                                UserHeater = true;
                            } else {
                                UserHeater = false;
                            }
                            if (data.contains("UserTVOn=true")) {
                                UserTV = true;
                            } else {
                                UserTV = false;
                            }
                            if (data.contains("UserAircon=true")) {
                                UserAircon = true;
                            } else {
                                UserAircon = false;
                            }
                            if (data.contains("UserCallOn=true")) {
                                UserCall = true;
                            } else {
                                UserCall = false;
                            }
                            if (data.contains("VideoURL=")) {
                                VideoURL = "";
                                StringTokenizer st = new StringTokenizer(data, ", ");
                                String [] array = new String[st.countTokens()];
                                int j = 0;
                                while (st.hasMoreElements()) {
                                    array[j++] = st.nextToken();
                                }
                                String videoofid = array[4].substring(9);
                                VideoURL = videoofid;
                            }

                            updateGetResponseOnUIThread(mid, data);

                        }

                        @Override
                        public void onUploadProgress(long bytes, long contentLen, boolean done) {
                        }

                        @Override
                        public void onDownloadProgress(long bytes, long contentLen, boolean done) {
                        }
                    });

        } catch (ApiException exc) {
            processFailure(tag, exc);
        }
    }


    public void postMsg() {
        final String tag = TAG + " sendMessageActionAsync";

        Message msg = new Message();
        msg.setSdid(Config.DEVICE_ID);
        msg.getData().put("UserAircon", UserAircon);
        msg.getData().put("UserHeater", UserHeater);
        msg.getData().put("UserLED", UserLED);
        msg.getData().put("UserMotorSetUp", UserMotor);
        msg.getData().put("UserTVOn", UserTV);
        msg.getData().put("UserCallOn", UserCall);
        msg.getData().put("VideoURL", VideoURL);


        try {
            mMessagesApi.sendMessageAsync(msg, new ApiCallback<MessageIDEnvelope>() {
                @Override
                public void onFailure(ApiException exc, int i, Map<String, List<String>> stringListMap) {
                    processFailure(tag, exc);
                }

                @Override
                public void onSuccess(MessageIDEnvelope result, int i, Map<String, List<String>> stringListMap) {
                    Log.v(tag, " onSuccess response to sending message = " + result.getData().toString());
                    updateSendResponseOnUIThread(result.getData().toString());
                }

                @Override
                public void onUploadProgress(long bytes, long contentLen, boolean done) {
                }

                @Override
                public void onDownloadProgress(long bytes, long contentLen, boolean done) {
                }
            });
        } catch (ApiException exc) {
            processFailure(tag, exc);
        }
    }


    public void showErrorOnUIThread(final String text, final Activity activity) {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                int duration = Toast.LENGTH_LONG;
                Toast toast = Toast.makeText(activity.getApplicationContext(), text, duration);
                toast.show();
            }
        });
    }

    public void updateWelcomeViewOnUIThread(final String text) {
        this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
            }
        });
    }

    public void updateSendResponseOnUIThread(final String response) {
        this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
            }
        });
    }

    public void updateGetResponseOnUIThread(final String mid, final String msgData) {
        this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
            }
        });
    }

    public void processFailure(final String context, ApiException exc) {
        String errorDetail = " onFailure with exception" + exc;
        Log.w(context, errorDetail);
        exc.printStackTrace();
        showErrorOnUIThread(context+errorDetail, MessageActivity.this);
    }

////////////////////////////////////////////////////////////////////////////////////////////////////

    private void startVideoActivity() {
        Intent msgYoutubeIntent = new Intent(getApplicationContext(), YoutubePlayerActivity.class);
        msgYoutubeIntent.putExtra("VideoURL", VideoURL);
        msgYoutubeIntent.putExtra("UserTV",UserTV);
        startActivity(msgYoutubeIntent);
        }

    private void finishVideoActivity() {
        this.finish();
    }


    class startTVAsyncTask extends AsyncTask<Boolean, Boolean, Float> {
        @Override
        protected Float doInBackground(Boolean... params) {

            while (!UserTV) {
                try {
                    Thread.sleep(5000);
                    getLatestMsg();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                if (this.isCancelled()) {
                    return null;
                }
            }

            return null;
        }

        @Override
        protected void onCancelled(Float result)   {
            super.onCancelled(result);
        }

        @Override
        protected void onPostExecute(Float result) {
            super.onPostExecute(result);
            startVideoActivity();
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            try {
                Thread.sleep(2000);
                if (UserTV) {
                    startVideoActivity();
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        @Override
        protected void onProgressUpdate(Boolean... CheckTV) {
        }
    }


} //MessageActivity


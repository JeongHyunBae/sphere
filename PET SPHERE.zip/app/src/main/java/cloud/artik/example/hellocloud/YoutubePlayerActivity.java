package cloud.artik.example.hellocloud;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Message;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;

import static android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP;

import static cloud.artik.example.hellocloud.MessageActivity.UserTV;
/**
 * Created by kje 2018-06
 * play the selected video
 * if the video is end, send messages to the artik cloud
 * check artik cloud message every 10 seconds(can be reduced)
 * if UserTV = false, go back to Message Activity and receving messages again
 */

public class YoutubePlayerActivity extends YouTubeBaseActivity {
    private static final String TAG = YoutubePlayerActivity.class.getSimpleName();
    private String videoID;
    private YouTubePlayerView youTubePlayerView;
    private StateChangeListener endlistener;

    public static String DEVELOPER_KEY = "";//key of google youtube version 3 API

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.youtube_player_activity);
        gobackAsyncTask returnthread = new gobackAsyncTask();
        //get the video id
        UserTV = getIntent().getBooleanExtra("UserTV", false);
        videoID = getIntent().getStringExtra("VideoURL");
        youTubePlayerView = (YouTubePlayerView)findViewById(R.id.youtube_player_view);
        endlistener = new StateChangeListener();
        initializeYoutubePlayer();

        returnthread.execute((Boolean)false);

    }

    /**
     * initialize the youtube player
     */
    private void initializeYoutubePlayer() {

        youTubePlayerView.initialize(DEVELOPER_KEY, new YouTubePlayer.OnInitializedListener() {

            @Override
            public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer youTubePlayer,
                                                boolean wasRestored) {

                //if initialization success then  the video id to youtube player
                if (!wasRestored) {
                    //set the player style here: like CHROMELESS, MINIMAL, DEFAULT
                    youTubePlayer.setPlayerStyle(YouTubePlayer.PlayerStyle.CHROMELESS);

                    //load the video
                    youTubePlayer.loadVideo(videoID);
                    //OR

                    //cue the video
                    //youTubePlayer.cueVideo(videoID);

                    //if you want when activity start it should be in full screen uncomment below comment
                    youTubePlayer.setFullscreen(true);
                    youTubePlayer.setPlayerStateChangeListener(endlistener);
                    //If you want the video should play automatically then uncomment below comment
                    //youTubePlayer.play();

                    //If you want to control the full screen event you can uncomment the below code
                    //Tell the player you want to control the fullscreen change
                   /*player.setFullscreenControlFlags(YouTubePlayer.FULLSCREEN_FLAG_CUSTOM_LAYOUT);
                    //Tell the player how to control the change
                    player.setOnFullscreenListener(new YouTubePlayer.OnFullscreenListener() {
                        @Override
                        public void onFullscreen(boolean arg0) {
                            // do full screen stuff here, or don't.
                            Log.e(TAG,"Full screen mode");
                        }
                    });*/

                }
            }

            @Override
            public void onInitializationFailure(YouTubePlayer.Provider arg0, YouTubeInitializationResult arg1) {
                //print or show error if initialization failed
                Log.e(TAG, "Youtube Player View initialization failed");
            }
        });
    }

    private final class StateChangeListener implements YouTubePlayer.PlayerStateChangeListener {

        @Override
        public void onLoading(){

        }

        @Override
        public void onLoaded(String s) {

        }

        @Override
        public void onAdStarted() {

        }

        @Override
        public void onVideoStarted() {

        }

        @Override
        public void onVideoEnded() {
            UserTV = false;
            ((MessageActivity)MessageActivity.mContext).postMsg();
        }

        @Override
        public void onError(YouTubePlayer.ErrorReason errorReason) {

        }
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////
    private void gobackActivity() {
        Intent youtubeintent = new Intent(this, MessageActivity.class);
        youtubeintent.addFlags(FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(youtubeintent);
        this.finish();
    }


    public class gobackAsyncTask extends AsyncTask<Boolean, Boolean, Float> {
        @Override
        protected Float doInBackground(Boolean... params) {
            while (UserTV) {
                try {
                    Thread.sleep(10000);
                    ((MessageActivity)MessageActivity.mContext).getLatestMsg();

                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                if (this.isCancelled()) {
                    return null;
                }
            }

            return null;
        }

        @Override
        protected void onCancelled(Float result)   {
            super.onCancelled(result);
        }

        @Override
        protected void onPostExecute(Float result) {
            super.onPostExecute(result);
            gobackActivity();
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onProgressUpdate(Boolean... CheckTV) {
            super.onProgressUpdate(CheckTV);
        }
    }
}

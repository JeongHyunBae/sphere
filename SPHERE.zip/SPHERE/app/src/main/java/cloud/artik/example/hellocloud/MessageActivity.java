/*
 * Copyright (C) 2017 Samsung Electronics Co., Ltd.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package cloud.artik.example.hellocloud;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import cloud.artik.api.MessagesApi;
import cloud.artik.api.UsersApi;
import cloud.artik.client.ApiCallback;
import cloud.artik.client.ApiClient;
import cloud.artik.client.ApiException;
import cloud.artik.model.Message;
import cloud.artik.model.MessageIDEnvelope;
import cloud.artik.model.NormalizedMessagesEnvelope;
import cloud.artik.model.UserEnvelope;

import static cloud.artik.example.hellocloud.Config.DEVICE_ID;

/**
 * Modified by kje 2018-06
 * This code will control smart pet house remotely
 * sending messages to the artik cloud to take actions
 * on/off LED, TV, heater, air conditioner
 * offering food and watch the pet
 */

public class MessageActivity extends Activity {
    public static Context mContext;
    private static final String TAG = "MessageActivity";

    private static UsersApi mUsersApi = null;
    private static MessagesApi mMessagesApi = null;

    private static String mAccessToken;

    public static boolean adminOn = false;
    public static boolean UserAircon = false;
    public static boolean UserHeater = false;
    public static boolean UserLED = false;
    public static int UserMotor = 1;
    public static boolean UserTV = false;
    public static boolean UserCall = false;
    public static String   VideoURL = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);
        mContext = this;

        AuthStateDAL authStateDAL = new AuthStateDAL(this);
        mAccessToken = authStateDAL.readAuthState().getAccessToken();
        Log.v(TAG, "::onCreate get access token = " + mAccessToken);


        final ToggleButton LED = (ToggleButton)findViewById(R.id.LED);
        final ToggleButton Food = (ToggleButton)findViewById(R.id.Food);
        final ToggleButton Cool = (ToggleButton)findViewById(R.id.Cool);
        final ToggleButton Heat = (ToggleButton)findViewById(R.id.Heat);
        final ToggleButton TV = (ToggleButton)findViewById(R.id.TV);
        final ToggleButton Call = (ToggleButton)findViewById(R.id.Call);
        final Switch Admin = (Switch)findViewById(R.id.Admin);
        final TextView mode = (TextView)findViewById(R.id.Mode);

        setupArtikCloudApi();
        getUserInfo();


    /**
     *  Manual(Admin = true) : User controls the pet house
     *  Auto(Admin = false) : pet house is controlled automatically by the sensor values
     */
        Admin.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Log.v(TAG, ": send button is clicked.");

                // Reset UI
                if (Admin.isChecked()) {
                    adminOn = true;
                    mode.setText("Manual");
                } else {
                    adminOn = false;
                    mode.setText("Auto");
                }
                postMsg();
            }
        });

        /**
         *  Sending messages to the artik cloud
         */
        LED.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Log.v(TAG, ": send button is clicked.");
                if (LED.isChecked()) {
                    UserLED = true;
                } else {
                    UserLED = false;
                }
                postMsg();
            }
        });

        Food.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Log.v(TAG, ": send button is clicked.");
                if (Food.isChecked()) {
                    UserMotor = 1;
                } else {
                    UserMotor = 0;
                }
                postMsg();
            }
        });

        Cool.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Log.v(TAG, ": send button is clicked.");
                if (Cool.isChecked()) {
                    UserAircon = true;
                } else {
                    UserAircon = false;
                }
                postMsg();
            }
        });

        Heat.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Log.v(TAG, ": send button is clicked.");
                if (Heat.isChecked()) {
                    UserHeater = true;
                } else {
                    UserHeater = false;
                }
                postMsg();
            }
        });

        //go to TVActivity
        TV.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Log.v(TAG, ": send button is clicked.");
                // Reset UI
                TV.setChecked(UserTV);
                startTV();
            }
        });

        //play watching app
        Call.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Log.v(TAG, ": send button is clicked.");

                // Reset UI
                if (Call.isChecked()) {
                    UserCall = true;
                } else {
                    UserCall = false;
                }
                postMsg();

                if (getPackageList()) {
                    Intent intent = getPackageManager().getLaunchIntentForPackage("com.ivuu");
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                } else{
                    String url = "market://details?id=" + "com.ivuu";
                    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(i);
                }
            }
        });

    }

    @Override
    public void onStart() {
        super.onStart();
        final ToggleButton LED = (ToggleButton)findViewById(R.id.LED);
        final ToggleButton Food = (ToggleButton)findViewById(R.id.Food);
        final ToggleButton Cool = (ToggleButton)findViewById(R.id.Cool);
        final ToggleButton Heat = (ToggleButton)findViewById(R.id.Heat);
        final ToggleButton TV = (ToggleButton)findViewById(R.id.TV);
        final ToggleButton Call = (ToggleButton)findViewById(R.id.Call);
        final Switch Admin = (Switch)findViewById(R.id.Admin);
        final TextView mode = (TextView)findViewById(R.id.Mode);
        getLatestMsg(mode,Admin, LED, Food, Cool, Heat, TV, Call);
    }

    public boolean getPackageList() {
        boolean isExist = false;

        PackageManager pkgMgr = getPackageManager();
        List<ResolveInfo> mApps;
        Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
        mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);
        mApps = pkgMgr.queryIntentActivities(mainIntent, 0);

        try {
            for (int i = 0; i < mApps.size(); i++) {
                if(mApps.get(i).activityInfo.packageName.startsWith("com.ivuu")){
                    isExist = true;
                    break;
                }
            }
        }
        catch (Exception e) {
            isExist = false;
        }
        return isExist;
    }

    public void setupArtikCloudApi() {
        ApiClient mApiClient = new ApiClient();
        mApiClient.setAccessToken(mAccessToken);

        mUsersApi = new UsersApi(mApiClient);
        mMessagesApi = new MessagesApi(mApiClient);
    }

    public void getUserInfo()
    {
        final String tag = TAG + " getSelfAsync";
        try {
            mUsersApi.getSelfAsync(new ApiCallback<UserEnvelope>() {
                @Override
                public void onFailure(ApiException exc, int statusCode, Map<String, List<String>> map) {
                    processFailure(tag, exc);
                }

                @Override
                public void onSuccess(UserEnvelope result, int statusCode, Map<String, List<String>> map) {
                    Log.v(TAG, "getSelfAsync::setupArtikCloudApi self name = " + result.getData().toString());
                    updateWelcomeViewOnUIThread("Welcome " + result.getData().getFullName());
                }

                @Override
                public void onUploadProgress(long bytes, long contentLen, boolean done) {
                }

                @Override
                public void onDownloadProgress(long bytes, long contentLen, boolean done) {
                }
            });
        } catch (ApiException exc) {
            processFailure(tag, exc);
        }
    }

    //get the last message of artik cloud
    public void getLatestMsg(final TextView mode,final Switch Admin, final ToggleButton LED, final ToggleButton Food, final ToggleButton Cool,
                              final ToggleButton Heat, final ToggleButton TV, final ToggleButton Call) {
        final String tag = TAG + " getLastNormalizedMessagesAsync";
        try {
            int messageCount = 1;
            mMessagesApi.getLastNormalizedMessagesAsync(messageCount, DEVICE_ID, null,
                    new ApiCallback<NormalizedMessagesEnvelope>() {
                        @Override
                        public void onFailure(ApiException exc, int i, Map<String, List<String>> stringListMap) {
                            processFailure(tag, exc);
                        }

                        @Override
                        public void onSuccess(NormalizedMessagesEnvelope result, int i, Map<String, List<String>> stringListMap) {
                            Log.v(tag, " onSuccess latestMessage = " + result.getData().toString());

                            String mid = "";
                            String data = "";
                            if (!result.getData().isEmpty()) {
                                mid = result.getData().get(0).getMid();
                                data = result.getData().get(0).getData().toString();
                            }

                            if (data.contains("adminOn=true")) {
                                adminOn = true;
                            } else {
                                adminOn = false;
                            }
                            if (data.contains("UserLED=true")) {
                                UserLED = true;
                            } else {
                                UserLED = false;
                            }
                            if (data.contains("UserHeater=true")) {
                                UserHeater = true;
                            } else {
                                UserHeater = false;
                            }
                            if (data.contains("UserTVOn=true")) {
                                UserTV = true;
                            } else {
                                UserTV = false;
                            }
                            if (data.contains("UserAircon=true")) {
                                UserAircon = true;
                            } else {
                                UserAircon = false;
                            }
                            if (data.contains("UserCallOn=true")) {
                                UserCall = true;
                            } else {
                                UserCall = false;
                            }
                            if (data.contains("UserMotor")) {
                                for (int k = 0; k < 8; k++) {
                                    if (data.contains("UserMotor="+k)) {
                                        UserMotor = k;
                                    }
                                }
                            }
                            if (data.contains("VideoURL=")) {
                                VideoURL = "";

                                StringTokenizer st = new StringTokenizer(data, ", ");
                                String[] array = new String[st.countTokens()];
                                int j = 0;
                                while (st.hasMoreElements()) {
                                    array[j++] = st.nextToken();
                                }

                                String videoofid = array[4].substring(9);
                                VideoURL = videoofid;
                            }

                            updateGetResponseOnUIThread(mode,Admin, LED, Food, Cool, Heat, TV, Call);

                        }

                        @Override
                        public void onUploadProgress(long bytes, long contentLen, boolean done) {
                        }

                        @Override
                        public void onDownloadProgress(long bytes, long contentLen, boolean done) {
                        }
                    });

        } catch (ApiException exc) {
            processFailure(tag, exc);
        }
    }

    //post Messages to the artik cloud
    public void postMsg() {
        final String tag = TAG + " sendMessageActionAsync";

        Message msg = new Message();
        msg.setSdid(Config.DEVICE_ID);
        msg.getData().put("UserAircon", UserAircon);
        msg.getData().put("UserHeater", UserHeater);
        msg.getData().put("UserLED", UserLED);
        msg.getData().put("UserMotor", UserMotor);
        msg.getData().put("UserTVOn", UserTV);
        msg.getData().put("UserCallOn", UserCall);
        msg.getData().put("VideoURL", VideoURL);
        msg.getData().put("adminOn",adminOn);

        try {
            mMessagesApi.sendMessageAsync(msg, new ApiCallback<MessageIDEnvelope>() {
                @Override
                public void onFailure(ApiException exc, int i, Map<String, List<String>> stringListMap) {
                    processFailure(tag, exc);
                }

                @Override
                public void onSuccess(MessageIDEnvelope result, int i, Map<String, List<String>> stringListMap) {
                    Log.v(tag, " onSuccess response to sending message = " + result.getData().toString());
                    updateSendResponseOnUIThread(result.getData().toString());
                }

                @Override
                public void onUploadProgress(long bytes, long contentLen, boolean done) {
                }

                @Override
                public void onDownloadProgress(long bytes, long contentLen, boolean done) {
                }
            });
        } catch (ApiException exc) {
            processFailure(tag, exc);
        }
    }

    static void showErrorOnUIThread(final String text, final Activity activity) {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                int duration = Toast.LENGTH_LONG;
                Toast toast = Toast.makeText(activity.getApplicationContext(), text, duration);
                toast.show();
            }
        });
    }

    private void updateWelcomeViewOnUIThread(final String text) {
        this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
            }
        });
    }

    private void updateSendResponseOnUIThread(final String response) {
        this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
            }
        });
    }

    private void updateGetResponseOnUIThread(final TextView mode, final Switch Admin, final ToggleButton LED, final ToggleButton Food, final ToggleButton Cool,
                                             final ToggleButton Heat, final ToggleButton TV, final ToggleButton Call) {
        this.runOnUiThread(new Runnable() {
            @Override
            public void run() {

                Admin.setChecked(adminOn);
                LED.setChecked(UserLED);
                Cool.setChecked(UserAircon);
                Heat.setChecked(UserHeater);
                TV.setChecked(UserTV);
                Call.setChecked(UserCall);

                if (UserMotor == 0) {
                    Food.setChecked(false);
                } else if (UserMotor > 0) {
                    Food.setChecked(true);
                }
                if (adminOn) {
                    mode.setText("Manual");
                } else {
                    mode.setText("Auto");
                }

            }
        });
    }

    private void processFailure(final String context, ApiException exc) {
        String errorDetail = " onFailure with exception" + exc;
        Log.w(context, errorDetail);
        exc.printStackTrace();
        showErrorOnUIThread(context+errorDetail, MessageActivity.this);
    }

    private void onPause(Bundle savedInstanceState) {
        super.onPause();
    }

    private void startTV() {
        Intent msgActivityIntent = new Intent(this, TVActivity.class);
        msgActivityIntent.putExtra("UserAircon", UserAircon);
        msgActivityIntent.putExtra("UserHeater", UserHeater);
        msgActivityIntent.putExtra("UserLED", UserLED);
        msgActivityIntent.putExtra("UserMotor", UserMotor);
        msgActivityIntent.putExtra("UserTV", UserTV);
        msgActivityIntent.putExtra("UserCall", UserCall);
        msgActivityIntent.putExtra("Video", VideoURL);
        startActivity(msgActivityIntent);
    }
} //MessageActivity


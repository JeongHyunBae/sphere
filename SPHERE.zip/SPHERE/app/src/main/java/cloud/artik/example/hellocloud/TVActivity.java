package cloud.artik.example.hellocloud;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ArrayAdapter;
import android.widget.ToggleButton;

import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubeThumbnailLoader;
import com.google.android.youtube.player.YouTubeThumbnailView;

import java.util.ArrayList;
import java.util.List;

import cloud.artik.api.MessagesApi;
import cloud.artik.api.UsersApi;

/**
 * Created by kje 2018-06
 * This code will add the list of youtube videos, showing thumbnail, video number and state of play
 * adding the http url of youtube videos.
 * sending commands to the slave android app to show pet tv remotely
 * This is demo version, not including data base at this moment,
 * however, utilizing DBHelper class and SQLite, saving and loading are also able.
 */

public class TVActivity extends Activity {
    private static final String TAG = "TVActivity";

    private UsersApi mUsersApi = null;
    private MessagesApi mMessagesApi = null;

    private String mAccessToken;
    private String thumbnailid; //youtube video ID

    private int listindex = -1; //index of video list
    private boolean playchecker; //check whether tv is on or not
    private boolean OnDeleteflag = true; // determine action between delete and start TV
    public MediaList newmedia; //list of video ID, name and state
    public ArrayList<MediaList> mlist =  new ArrayList<MediaList>(); //list of newmedia
    public MediaAdapter madapter; //list adaptor

    public static String DEVELOPER_KEY = "";
    //key of google youtube version 3 API
    addYoutubeActivity TVDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tv);
        final ListView list = (ListView) findViewById(R.id.listview);

        Button Add = (Button) findViewById(R.id.add);
        Button Delete = (Button) findViewById(R.id.delete);
        Button Search = (Button) findViewById(R.id.search);
        list.setFocusable(false);
        Add.setFocusable(false);
        Delete.setFocusable(false);
        Search.setFocusable(false);

        //this is not necessary, but for safety during postMsg
        Intent msgActivityIntent = getIntent();
        boolean UserAircon = msgActivityIntent.getBooleanExtra("UserAircon", false);
        boolean UserHeater = msgActivityIntent.getBooleanExtra("UserHeater", false);
        boolean UserLED = msgActivityIntent.getBooleanExtra("UserLED", false);
        boolean UserMotor = msgActivityIntent.getBooleanExtra("UserMotor", false);
        boolean UserTV = msgActivityIntent.getBooleanExtra("UserTV", false);
        boolean UserCall = msgActivityIntent.getBooleanExtra("UserCall", false);

        thumbnailid = msgActivityIntent.getStringExtra("VideoURL");

        AuthStateDAL authStateDAL = new AuthStateDAL(this);
        mAccessToken = authStateDAL.readAuthState().getAccessToken();
        Log.v(TAG, "::onCreate get access token = " + mAccessToken);

        //examples of videos.
        newmedia = new MediaList("1zZ0U_y3oTw", "video1", false);
        mlist.add(newmedia);
        newmedia = new MediaList("29XcBZl47Vs", "video2", false);
        mlist.add(newmedia);
        madapter = new MediaAdapter(this, mlist);

        list.setAdapter(madapter);

        list.deferNotifyDataSetChanged();
        ((MessageActivity)MessageActivity.mContext).setupArtikCloudApi();
        ((MessageActivity)MessageActivity.mContext).getUserInfo();

        //when clicked list,
        //send commands to the slave app to play selected youtube videos
        //if delete button was clicked before, then delete selected video
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                listindex = position;
                //playing selected video
                if (OnDeleteflag) {
                    Log.v(TAG, "position: " + position + ", list index:" + listindex);
                    for (int j = 0; j < mlist.size(); j++) {
                        if (mlist.get(j).state) {
                            playchecker = false;
                            break;
                        } else {
                            playchecker = true;
                        }
                    } //check if another video is playing
                    Log.v(TAG, "playchecker: " + playchecker);
                    //when another video is playing
                    if (!playchecker && !mlist.get(position).state) {
                        Toast.makeText(TVActivity.this, "다른 동영상이 실행 중입니다.", Toast.LENGTH_LONG).show();
                        MessageActivity.UserTV = true;
                        MessageActivity.VideoURL = mlist.get(position).thumbnail;
                        ((MessageActivity) MessageActivity.mContext).postMsg();
                    } else if (mlist.get(position).state) { //when playing video is selected
                        mlist.get(position).state = false;
                        madapter.notifyDataSetChanged();
                        Toast.makeText(TVActivity.this, "동영상을 종료하였습니다.", Toast.LENGTH_LONG).show();
                        MessageActivity.UserTV = false;
                        MessageActivity.VideoURL = mlist.get(position).thumbnail;
                        ((MessageActivity) MessageActivity.mContext).postMsg();
                    } else if (playchecker) { //video play start
                        mlist.get(position).state = true;
                        madapter.notifyDataSetChanged();
                        Toast.makeText(TVActivity.this, (position + 1) + "번 동영상을 실행합니다.", Toast.LENGTH_LONG).show();
                        MessageActivity.UserTV = true;
                        MessageActivity.VideoURL = mlist.get(position).thumbnail;
                        ((MessageActivity) MessageActivity.mContext).postMsg();
                    }
                    Log.v(TAG, "position: " + position + ", list index:" + listindex + ", state: " + mlist.get(position).state);
                } else { //delete button was selected before clicking list
                    mlist.remove(listindex);
                    madapter.notifyDataSetChanged();
                    listindex = -1;
                    OnDeleteflag = true;
                }
            }
        });

        DisplayMetrics dm = getApplicationContext().getResources().getDisplayMetrics(); //get the window size of device
        int width = dm.widthPixels; //width of device
        int height = dm.heightPixels; //height og device


        final addYoutubeActivity TVDialog = new addYoutubeActivity(this);
        WindowManager.LayoutParams wm = TVDialog.getWindow().getAttributes();  //set the width and height of dialog
        wm.copyFrom(TVDialog.getWindow().getAttributes());  //put this into the dialog setting
        wm.width = width / 2;  //화면 너비의 절반
        wm.height = height / 2;  //화면 높이의 절반

        Add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                TVDialog.setOnShowListener(new DialogInterface.OnShowListener() {
                    @Override
                    public void onShow(DialogInterface dialog) {

                    }
                });
                //create pop up window for adding youtube video
                TVDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                    @Override
                    public void onCancel(DialogInterface dialog) {
                            thumbnailid = TVDialog.getURL();
                        if (thumbnailid.equals("wrong")) {
                            Toast.makeText(TVActivity.this, "Wrong URL input.", Toast.LENGTH_LONG).show();
                        } else if (thumbnailid.equals("")) {

                        }
                        else { //add the new youtube video
                            int mlistindex = mlist.size();
                            mlistindex = mlistindex + 1;
                            newmedia = new MediaList(thumbnailid, "video" + mlistindex, false);
                            mlist.add(newmedia);
                            madapter.notifyDataSetChanged();
                        }

                    }
                });

                TVDialog.show();

            }
        });

        Delete.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Toast.makeText(TVActivity.this, "지울 동영상을 선택하세요", Toast.LENGTH_LONG).show();
                Log.v(TAG, ": Delete button is clicked.");

                OnDeleteflag = false;

            }
        });

        //offer easy way to search for youtube videos
        Search.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Toast.makeText(TVActivity.this, "동영상을 고르고 URL을 복사하세요.", Toast.LENGTH_LONG).show();
                //open the Youtube Player app
                if (getPackageList()) {
                    Intent intent = getPackageManager().getLaunchIntentForPackage("com.google.android.youtube");
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                } else{
                    String url = "market://details?id=" + "com.google.android.youtube";
                    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    startActivity(i);
                }
            }
        });
    }
    //check if the device has youtube player app
    public boolean getPackageList() {
        boolean isExist = false;

        PackageManager pkgMgr = getPackageManager();
        List<ResolveInfo> mApps;
        Intent mainIntent = new Intent(Intent.ACTION_MAIN, null);
        mainIntent.addCategory(Intent.CATEGORY_LAUNCHER);
        mApps = pkgMgr.queryIntentActivities(mainIntent, 0);

        try {
            for (int i = 0; i < mApps.size(); i++) {
                if(mApps.get(i).activityInfo.packageName.startsWith("com.google.android.youtube")){
                    isExist = true;
                    break;
                }
            }
        }
        catch (Exception e) {
            isExist = false;
        }
        return isExist;
    }

    //list of video id, title and playing state
    public class MediaList {
        public String thumbnail;
        public String name;
        public boolean state;

        public MediaList(String thumbnail, String name, boolean state) {
            this.thumbnail = thumbnail;
            this.name = name;
            this.state = state;
        }
    }

    //adapter of MediaList
    public class MediaAdapter extends ArrayAdapter<MediaList> {
        // View lookup cache, for soft showing window
        private class ViewHolder {
            YouTubeThumbnailView thumbnailview;
            TextView name;
            ToggleButton state;
        }

        public MediaAdapter(Context context, ArrayList<MediaList> newmedia) {
            super(context, R.layout.custom_view, newmedia);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            // Get the data item for this position
            final MediaList mlist = getItem(position);
            // Check if an existing view is being reused, otherwise inflate the view
            ViewHolder viewHolder; // view lookup cache stored in tag
            if (convertView == null) {
                // If there's no view to re-use, inflate a brand new view for row
                viewHolder = new ViewHolder();
                LayoutInflater inflater = LayoutInflater.from(getContext());
                convertView = inflater.inflate(R.layout.custom_view, parent, false);
                viewHolder.thumbnailview = (YouTubeThumbnailView) convertView.findViewById(R.id.video_thumbnail_image_view);
                viewHolder.name = (TextView) convertView.findViewById(R.id.video_title_label);
                viewHolder.state = (ToggleButton) convertView.findViewById(R.id.video_duration_label);
                viewHolder.state.setFocusable(false);
                // Cache the viewHolder object inside the fresh view
                convertView.setTag(viewHolder);
            } else {
                // View is being recycled, retrieve the viewHolder object from tag
                viewHolder = (ViewHolder) convertView.getTag();
            }
            // Populate the data from the data object via the viewHolder object
            // into the template view.
            viewHolder.thumbnailview.initialize(DEVELOPER_KEY, new YouTubeThumbnailView.OnInitializedListener() {
                @Override
                public void onInitializationSuccess(YouTubeThumbnailView youTubeThumbnailView, final YouTubeThumbnailLoader youTubeThumbnailLoader) {
                    //when initialization is sucess, set the video id to thumbnail to load
                    youTubeThumbnailLoader.setVideo(mlist.thumbnail);

                    youTubeThumbnailLoader.setOnThumbnailLoadedListener(new YouTubeThumbnailLoader.OnThumbnailLoadedListener() {
                        @Override
                        public void onThumbnailLoaded(YouTubeThumbnailView youTubeThumbnailView, String s) {
                            //when thumbnail loaded successfully release the thumbnail loader as we are showing thumbnail in adapter
                            youTubeThumbnailLoader.release();
                        }

                        @Override
                        public void onThumbnailError(YouTubeThumbnailView youTubeThumbnailView, YouTubeThumbnailLoader.ErrorReason errorReason) {
                            //print or show error when thumbnail load failed
                            Log.e(TAG, "Youtube Thumbnail Error");
                        }
                    });
                }

                @Override
                public void onInitializationFailure(YouTubeThumbnailView youTubeThumbnailView, YouTubeInitializationResult youTubeInitializationResult) {
                    //print or show error when initialization failed
                    Log.e(TAG, "Youtube Initialization Failure");

                }
            });

            viewHolder.name.setText(mlist.name);
            viewHolder.state.setChecked(mlist.state);
            // Return the completed view to render on screen
            return convertView;
        }
    }
} //TVActivity


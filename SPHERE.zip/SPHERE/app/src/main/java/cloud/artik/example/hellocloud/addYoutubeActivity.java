/*
 * Copyright (C) Team SPHERE in Sungkyunkwan University
 */

package cloud.artik.example.hellocloud;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.StringTokenizer;
/**
 * Created by kje 2018-06
 * This code will pop up after clicking ADD button on TVActivity window.
 * recognizing the video id of youtube URL which was input.
 */
public class addYoutubeActivity extends Dialog {

    public addYoutubeActivity (Context context) {
        super(context);
    }

    private String mode;
    private String address;

    private TextView title;
    private EditText input;
    private Button yes;
    private Button no;

    private boolean yesflag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);

        setContentView(R.layout.addbutton);

        title = (TextView)findViewById(R.id.title);
        input = (EditText)findViewById(R.id.input);
        yes   = (Button)findViewById(R.id.yes);
        no    = (Button)findViewById(R.id.no);

        input.setText("");

        yes.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                yesflag = true;
                cancel();
            }
        });

        no.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                yesflag = false;
                cancel();
            }
        });
    }

    @Override
    public void onStart() {
        super.onStart();
        input.setText("");
        yesflag = false;
    }

    /**
     * getURL function
     * This code will get the video ID from youtube URL
     * which exists after youtube.com/watch?v=
     */
    public String getURL() {
        address = input.getText().toString();

        String thumbnail = "";
        if (yesflag) {
            if (address.contains("youtube.com/watch?v=")) {
                StringTokenizer st = new StringTokenizer(address, "v=");
                String[] array = new String[st.countTokens()];
                int j = 0;
                while (st.hasMoreElements()) {
                    array[j++] = st.nextToken();
                }
                int size = array.length;
                String subthumbnail = "";
                for (int k = 1; k < size; k++) {
                    subthumbnail = subthumbnail + array[k];
                }
                thumbnail = subthumbnail;
            } else if (address.contains("youtu.be")) {
                StringTokenizer st = new StringTokenizer(address, "be");
                String[] array = new String[st.countTokens()];
                int k = 0;
                while (st.hasMoreElements()) {
                    array[k++] = st.nextToken();
                }
                int size = array.length;
                String subthumbnail = "";
                for (int m = 1; m < size; m++) {
                    subthumbnail = subthumbnail + array[m];
                }
                thumbnail = subthumbnail.substring(1);
            } else {
                thumbnail = "wrong";
            }
        } else if (!yesflag) {
            thumbnail = "";
        }
        System.out.println(thumbnail);
        return thumbnail;
    }
}
